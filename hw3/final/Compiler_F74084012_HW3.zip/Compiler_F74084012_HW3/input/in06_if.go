package main

func main() {
	var x int32 = 0
	if x == 0 { /* if */
		println("Hello")
		/* print
		a Hello with
		newline */
	}
}