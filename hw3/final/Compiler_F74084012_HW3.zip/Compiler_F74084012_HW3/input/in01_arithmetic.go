package main

func main() {
	var x int32 = 3
	var y int32 = 2
	println(x + y)
	println(x - y)
	println(x * y)
	println(x / y)
	println(x % y)
	x++
	println(x)
	x--
	println(x)

	var xx float32 = 3.1
	var yy float32 = 2.1
	println(xx + yy)
	println(xx - yy)
	println(xx * yy)
	println(xx / yy)
	xx++
	println(xx)
	xx--
	println(xx)
}